import json
import arrow
import requests

def lambda_handler(event, context):
    
    host = 'https://api.mealviewer.com/api/v4/school'
    school = 'HeritageES'
    tomorrow = arrow.utcnow().to('US/Eastern').shift(days=1).format('MM-DD-YYYY')
    url = f'{host}/{school}/{tomorrow}/{tomorrow}/0'

    r = requests.get(url)
    lunch_menu = r.json().get('menuSchedules')[0].get('menuBlocks')[1]
    entrees = [food['item_Name'] for food in lunch_menu.get('cafeteriaLineList').get('data')[0]['foodItemList']['data'] if food['item_Type'] == 'Entrees']

    output = "Tomorrow's delicious entrees include {0}, and {1}!".format(', '.join(entrees[:-1]), entrees[-1])
    
    return {
        'statusCode': 200,
        'body': json.dumps(output)
    }
